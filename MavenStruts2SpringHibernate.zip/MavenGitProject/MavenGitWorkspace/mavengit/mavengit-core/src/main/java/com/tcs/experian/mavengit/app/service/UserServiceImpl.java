package com.tcs.experian.mavengit.app.service;

import java.util.List;

import com.tcs.experian.mavengit.app.bean.UserBean;
import com.tcs.experian.mavengit.app.dao.UserDao;

public class UserServiceImpl implements UserService {
	private UserDao userDao;

	public UserDao getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	public List<UserBean> getUserList() throws Exception {
		return userDao.getUserList();
	}

	public UserBean getaddUser(UserBean userBean) throws Exception {
		return userDao.addUser(userBean);
	}

}
