package com.tcs.experian.mavengit.app.service;

import java.util.List;

import com.tcs.experian.mavengit.app.bean.UserBean;

public interface UserService {
	public List<UserBean> getUserList() throws Exception;

	public UserBean getaddUser(UserBean userBean) throws Exception;
}
